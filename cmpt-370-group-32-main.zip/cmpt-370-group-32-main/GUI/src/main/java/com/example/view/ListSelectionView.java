package com.example.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.text.Font;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import com.example.controller.*;
import com.example.model.*;
import com.example.util.*;

/**
 * View for the list of Personal Lists and Watched List
 */
public class ListSelectionView extends StackPane {
    ArrayList<MovieList> movieLists;
    PersonalListModel pModel;
    WatchedListModel wModel;
    AppController controller;
    VBox mainVBox;
    VBox listBox;
    public TextField createName;
    Button addNew;
    Button deleteCurr;
    Label listCount;
    Label maxCount;
    public ListSelectionView(){
        this.setPrefSize(300,600);
        this.setMaxSize(2000,1500);

        //listBox will contain the list of Personal Lists
        //mainVBox will contain the title, list box and the addition and deletion of list
        movieLists = new ArrayList<>();
        listBox = new VBox();
        listBox.setPrefSize(300,600);
        mainVBox = new VBox();
        mainVBox.setPrefSize(300,600);
        mainVBox.setSpacing(3);
        mainVBox.setPadding(new Insets(2,2,2,2));

        //titleHBox will have the title and the number of lists
        HBox titleHBox = new HBox();
        Label personalList = new Label("Personal Lists");
        personalList.setFont(new Font(20));
        //The count for lists
        HBox listCountBox = new HBox();
        listCount = new Label();
        maxCount = new Label();
        listCountBox.getChildren().addAll(listCount,maxCount);

        titleHBox.getChildren().addAll(personalList,listCountBox);
        titleHBox.setPrefWidth(300);

        //createHBox will contain the addition of lists
        HBox createHBox = new HBox();
        createHBox.setPrefWidth(300);
        createHBox.setPadding(new Insets(2,2,2,2));
        createHBox.setSpacing(8);
        Label createLabel = new Label("Create New:");
        createLabel.setAlignment(Pos.CENTER_LEFT);
        createName = new TextField();
        createName.setPromptText("Enter Name");
        createName.setPrefWidth(170);
        createName.setAlignment(Pos.CENTER_LEFT);
        addNew = new Button("ADD");
        addNew.setAlignment(Pos.CENTER_RIGHT);
        createHBox.getChildren().addAll(createLabel,createName,addNew);

        //deleteHBox will contain the deletion of list
        HBox deleteHBox = new HBox();
        deleteHBox.setPrefWidth(300);
        deleteHBox.setSpacing(138);
        deleteHBox.setPadding(new Insets(2,2,2,2));
        Label deleteLabel = new Label("Delete Current List");
        deleteLabel.setAlignment(Pos.CENTER_LEFT);
        deleteCurr = new Button("DELETE");
        deleteCurr.setAlignment(Pos.CENTER_RIGHT);
        deleteHBox.getChildren().addAll(deleteLabel,deleteCurr);

        listBox.setStyle("-fx-border-color: black;\n"+"-fx-border-insets: 2;\n"+
                "fx-border-width: 3;\n");

        mainVBox.getChildren().addAll(titleHBox,listBox,createHBox,deleteHBox);
        this.getChildren().add(mainVBox);
    }

    /**
     * Assigns the Personal List Model
     * @param newModel the Personal List Model used
     */
    public void setPModel(PersonalListModel newModel){
        pModel = newModel;
        listCount.setText(String.valueOf(pModel.getListCount()));
        maxCount.setText("/"+pModel.getMaxList());
    }

    /**
     * Assigns the Watched Model List
     * @param newModel the Watched List Model used
     */
    public void setWModel(WatchedListModel newModel){
        wModel = newModel;
        listBox.getChildren().add(wModel.getWatched().getButton());
    }

    /**
     * Gets the text field value used for addition of list
     * @return String value that will be the string's name
     */
    public String getTextString(){
        return this.createName.getText();
    }

    /**
     * Assigns the AppController
     * @param controller the AppController used
     */
    public void setController(AppController controller){
        this.controller = controller;
        deleteCurr.setOnAction(this.controller::handleClickDelete);
        addNew.setOnAction(this.controller::handleClickCreate);
        wModel.getWatched().getButton().setOnAction(e->{
            try {
                this.controller.handleClickWatched(e);
            }catch (FileNotFoundException ex){
                throw new RuntimeException(ex);
            }
        });
    }
    /**
     * This changes the view when the model changes
     */
    public void modelChanged(){
        listBox.getChildren().clear();
        listBox.getChildren().add(wModel.getWatched().getButton());
        listCount.setText(String.valueOf(pModel.getListCount()));
        maxCount.setText("/"+pModel.getMaxList());
        pModel.getUserLists().forEach(l ->{
            l.getButton().setOnAction(e->{
                l.selectedList();
                try {
                    this.controller.handleClickCurrent(e);
                } catch (FileNotFoundException ex) {
                    throw new RuntimeException(ex);
                }
            });
            listBox.getChildren().add(l.getButton());
        });
    }
}
