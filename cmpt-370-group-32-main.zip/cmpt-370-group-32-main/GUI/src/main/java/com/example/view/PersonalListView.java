package com.example.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

import java.util.ArrayList;

import com.example.model.*;
import com.example.util.*;

/**
 *  This view is for the Personal Lists, the creation/deletion of a list and the current movies inside the list
 */
public class PersonalListView  extends StackPane {
    Label listName;
    PersonalListModel model;
    VBox movieVBox;
    ObservableList<Movie> movieObs;
    ListView<Movie> movieListView;
    public PersonalListView(){
        this.setMaxSize(2000,1500);
        this.setPrefSize(600,600);

        //displayVBox will be the VBox containing everything
        VBox displayVBox = new VBox();
        ArrayList<Movie> movieArrayList = new ArrayList<>();
        movieObs = FXCollections.observableArrayList(movieArrayList);
        movieListView = new ListView<>(movieObs);

        //listName initialized, changes depending on the selected list
        this.listName = new Label("Select A List");
        listName.setFont(new Font(20));
        Label listDisplay = new Label("Selected List: ");
        listDisplay.setFont(new Font(20));

        //movieVBox will contain all the Movies in the selected Movie List
        movieVBox = new VBox();
        movieVBox.setMaxSize(2000,1500);
        movieVBox.setPrefSize(600,600);
        movieVBox.setSpacing(3);
        movieVBox.setPadding(new Insets(2,2,2,2));
        movieVBox.setStyle("-fx-border-color: black;\n"+"-fx-border-insets: 2;\n"+
                "fx-border-width: 3;\n");

        //Title
        HBox selectedHBox = new HBox();
        selectedHBox.getChildren().addAll(listDisplay,listName);
        selectedHBox.setSpacing(5);

        displayVBox.getChildren().addAll(selectedHBox,movieVBox);
        displayVBox.setMaxSize(2000,1500);
        displayVBox.setPrefSize(600,600);
        displayVBox.setPadding(new Insets(2,2,2,2));
        displayVBox.setSpacing(3);

        this.getChildren().add(displayVBox);
    }

    /**
     * Assigns the Personal List Model
     * @param newModel Personal List Model that is used
     */
    public void setModel(PersonalListModel newModel){this.model = newModel;}
    public void modelChanged(){
        movieVBox.getChildren().clear();
        listName.setText(model.getCurr().getListName());
        //If the selected Movie List doesn't contain any Movies
        if (model.getCurr().getMovieList().isEmpty()){
            Label emptyListLabel = new Label("The Current List Is Empty");
            movieVBox.getChildren().add(emptyListLabel);
        }
        //Else display the Movies
        else {
            movieObs = FXCollections.observableArrayList(model.getCurr().getMovieList());
            movieListView.setItems(movieObs);
            movieListView.setPrefSize(600,600);
            movieVBox.getChildren().add(movieListView);
        }
    }
}
