package com.example.util;

import java.util.ArrayList;

/**
 * Class for creating a list of movies, used for Personal Lists and the Movie History
 */

public class MovieList {
    ArrayList<Movie> movieList;
    String listName;
    ListButton button;
    Boolean selectStatus;
    public MovieList(String name){
        this.listName = name;
        this.movieList = new ArrayList<>();
        button = new ListButton(name);
        selectStatus = false;
    }

    /**
     * Button that is used by the Movie List
     * @return the Movie List button
     */
    public ListButton getButton(){
        return this.button;
    }

    /**
     * Gets the name of the List
     * @return String value that represents the List name
     */
    public String getListName(){return this.listName;}

    /**
     * Gets the Arraylist of Movies that the MovieList contains
     * @return ArrayList of Movies assigned to the MovieList
     */
    public ArrayList<Movie> getMovieList(){return this.movieList;}

    /**
     * This function adds a new Movie to the list
     * @param insert the Movie to be added
     */
    public void addMovie(Movie insert){
        if (!movieList.contains(insert)) {
            movieList.add(insert);
        }
    }

    /**
     * Changes the name of the list
     * @param newName the new name used for the List
     */
    public void changeListName(String newName){
        this.listName = newName;
    }

    /**
     * Deletes a specified movie in the list
     * @param delete the Movie to be deleted
     */
    public void deleteFromList(Movie delete){
        for (int i =0; i <= movieList.size()-1; i++){
            if (movieList.get(i).equals(delete)){
                movieList.remove(i);
                break;
            }
        }
    }

    /**
     * Gets the status of list if it is selected or not
     * @return Boolean the select status of the list
     */
    public Boolean getSelectStatus(){
        return selectStatus;
    }

    /**
     * Sets the List as selected
     */
    public void selectedList(){
        selectStatus = true;
        this.getButton().select();
    }

    /**
     * Unselects the list
     */
    public void unselectList(){
        selectStatus = false;
        this.getButton().unselect();
    }
    public String toString(){
        return this.getListName();
    }
}
