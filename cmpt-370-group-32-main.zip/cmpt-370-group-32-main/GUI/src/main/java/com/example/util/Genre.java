package com.example.util;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;

public class Genre {

    /**
     * The name of the genre
     */
    String name;


    /**
     * Constructor to create a Genre type
     * @param name a String containing the name of the genre
     */
    public Genre(String name){
        this.name = name;
    }

    /**
     * Sets the name of the genre
     * @param name a String of desired name
     */
    public void setName(String name){
        this.name = name;

    }

    /**
     * Gets the name of the gerne
     * @return a String of the current name
     */
    public String getName(){
        return this.name;
    }

    /**
     * Gets the top 5 movie recommendations based on the genre name by calling the Recommendations getRecs function
     * @return an ArrayList of Strings that are recommended movie names
     * @throws FileNotFoundException if the filename cannot be found
     */
    public ArrayList<String> getTop5Movies(String recommendationsDatabase) throws FileNotFoundException {
        //create recommendation object from this Genre
        Recommendations x = new Recommendations(this.name, recommendationsDatabase, 5);
        //get top 5 recs
        return x.getRecs();
    }

}
