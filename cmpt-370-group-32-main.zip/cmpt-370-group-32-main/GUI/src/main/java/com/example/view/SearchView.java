package com.example.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.application.Application;
import javafx.application.HostServices;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import com.example.controller.*;
import com.example.model.*;
import com.example.util.*;

/**
 * The View for searching a Movie, showing the search bar and the selected Movie
 */
public class SearchView extends StackPane {
    SearchModel searchModel;
    ObservableList<Movie> movieObs;
    ListView<Movie> movieListView;
    Button addToListButton;
    Button watchedButton;
    Button linkButton;
    Label movieNameLabel;
    Label ratingLabel;
    Label genreLabel;
    Label notesLabel;
    Label watchDateLabel;
    VBox recommendVBox;
    HBox watchedHBox;
    HBox addHBox;

    int fontSize;

    Label name;
    Label rating;
    Label ratingsEnding;
    Label genre;
    Label notes;
    Label watch;
    Label recommend;
    HBox ratingHBox;
    Boolean ratingSelect;
    Button decreaseButton;
    Button increaseButton;
    HBox notesHBox;
    public Boolean notesSelect;
    public TextField notesText;
    Button changeNotes;
    public SearchView(){
        this.setMaxSize(2000,1500);
        this.setPrefSize(500, 500);

        ArrayList<Movie> searchInsert = new ArrayList<>();
        movieObs = FXCollections.observableArrayList(searchInsert);
        movieListView = new ListView<>(movieObs);
        VBox vBox1 = new VBox();

        //These HBoxes are for the buttons
        addHBox = new HBox();
        watchedHBox = new HBox();
        notesText = new TextField();


        linkButton = new Button("Where to watch ");
        changeNotes = new Button("Save");
        decreaseButton = new Button("<-");
        increaseButton = new Button("->");

        Button openURLButton = new Button("Go!");
        //HostServices services = getHostServices();

        Hyperlink link = new Hyperlink("");

        ratingSelect = false;
        notesSelect = false;
        this.fontSize = 20;

        Label movieLabel = new Label("Movie Information");
        movieLabel.setFont(new Font(fontSize));

        watchedButton = new Button("WATCHED!");
        watchedButton.setAlignment(Pos.CENTER);
        addToListButton = new Button("ADD");
        addToListButton.setAlignment(Pos.CENTER);

        addToListButton.setAlignment(Pos.CENTER);
        addToListButton.setPrefHeight(50);
        addToListButton.setPrefWidth(150);

        watchedButton.setAlignment(Pos.CENTER);
        watchedButton.setPrefHeight(50);
        watchedButton.setPrefWidth(150);

        watchedHBox.setMaxWidth(2000);
        watchedHBox.setMaxWidth(500);
        watchedHBox.setSpacing(3);
        watchedHBox.setPadding(new Insets(2,2,2,2));

        addHBox.setMaxWidth(2000);
        addHBox.setPrefWidth(500);
        addHBox.setSpacing(3);
        addHBox.setPadding(new Insets(2,2,2,2));

        //The rest here will be for the Information display of the Movie
        HBox nameHBox = new HBox();
        name = new Label("Title: ");
        name.setFont(new Font(fontSize));
        movieNameLabel = new Label();
        Label movieName = movieNameLabel;
        movieName.setFont(new Font(fontSize));
        nameHBox.getChildren().addAll(name,movieName,linkButton);
        nameHBox.setSpacing(5);
        nameHBox.setPadding(new Insets(2,2,2,2));

        ratingHBox = new HBox();
        rating = new Label("Rating: ");
        rating.setFont(new Font(fontSize));
        ratingLabel = new Label();
        ratingLabel.setFont(new Font(fontSize));
        ratingsEnding = new Label("/10 ");
        ratingsEnding.setFont(new Font(fontSize));

        ratingHBox.getChildren().addAll(rating,ratingLabel,ratingsEnding);
        ratingHBox.setSpacing(3);
        ratingHBox.setPadding(new Insets(2,2,2,2));

        HBox genreHBox = new HBox();
        genre = new Label("Genre: ");
        genre.setFont(new Font(fontSize));
        genreLabel = new Label();
        Label gLabel = genreLabel;
        gLabel.setFont(new Font(fontSize));
        genreHBox.getChildren().addAll(genre,gLabel);
        genreHBox.setSpacing(5);
        genreHBox.setPadding(new Insets(2,2,2,2));

        notesHBox = new HBox();
        notes = new Label("Notes: ");
        notes.setFont(new Font(fontSize));
        notesLabel = new Label();
        notesLabel.setFont(new Font(fontSize));
        notesHBox.getChildren().addAll(notes,notesLabel);
        notesHBox.setSpacing(5);
        notesHBox.setPadding(new Insets(2,2,2,2));

        HBox watchDateHBox = new HBox();
        watch = new Label("Watch Date: ");
        watch.setFont(new Font(fontSize));
        watchDateLabel = new Label();
        Label wLabel = watchDateLabel;
        wLabel.setFont(new Font(fontSize));
        watchDateHBox.getChildren().addAll(watch,wLabel);
        watchDateHBox.setSpacing(5);
        watchDateHBox.setPadding(new Insets(2,2,2,2));

        //This will show the recommendations for the Movie
        VBox recommendationBox = new VBox();
        recommend = new Label("Recommendations: ");
        recommend.setFont(new Font(fontSize));
        recommendVBox = new VBox();
        recommendationBox.getChildren().addAll(recommend, recommendVBox);
        recommendationBox.setSpacing(3);
        recommendationBox.setPadding(new Insets(2,2,2,2));

        VBox movieInfoVBox = new VBox();
        movieInfoVBox.getChildren().addAll(nameHBox,ratingHBox,genreHBox,notesHBox,watchDateHBox, recommendationBox);
        movieInfoVBox.setMaxSize(2000,1000);
        movieInfoVBox.setPrefSize(500,400);
        movieInfoVBox.setStyle("-fx-border-color: black;\n" + "-fx-border-insets: 2;\n"+
                "fx-border-width: 3;\n");

        vBox1.getChildren().addAll(movieLabel,movieInfoVBox,watchedHBox,addHBox);
        vBox1.setMaxSize(2000,1500);
        vBox1.setPrefSize(500,500);
        vBox1.setPadding(new Insets(2,2,2,2));
        vBox1.setSpacing(3);

        this.getChildren().add(vBox1);
    }

    /**
     * Assigns the Search Model
     * @param newModel the Search Model used
     */
    public void setModel(SearchModel newModel){
        this.searchModel = newModel;
        this.fontSize = searchModel.getFontSize();
    }

    /**
     * Assigns the Controller to the buttons
     * @param controller AppController used
     */
    public void setController(AppController controller){
        addToListButton.setOnAction(controller::handleAdd);
        watchedButton.setOnAction(controller::handleWatched);
        linkButton.setOnAction(controller :: linkClicked);
        decreaseButton.setOnAction(e->{
            try {
                controller.handleDecreaseRating(e);
            } catch (FileNotFoundException ex) {
                throw new RuntimeException(ex);
            }
        });
        increaseButton.setOnAction(e->{
            try {
                controller.handleIncreaseRating(e);
            } catch (FileNotFoundException ex) {
                throw new RuntimeException(ex);
            }
        });
        changeNotes.setOnAction(e->{
            try {
                controller.handleNotesChange(e);
            } catch (FileNotFoundException ex) {
                throw new RuntimeException(ex);
            }
        });
    }

    /**
     * Determines which view will be set on the ratings section
     * @param event Action Event
     * @throws FileNotFoundException if database can't read the file
     */
    public void rateMovie(ActionEvent event) throws FileNotFoundException {
        ratingSelect = !ratingSelect;
        this.modelChanged();
    }

    /**
     * Determines which view will be set on the notes section
     * @param event ActionEvent
     * @throws FileNotFoundException if file not read
     */
    public void notesMovie(ActionEvent event) throws FileNotFoundException{
        notesSelect = !notesSelect;
        this.modelChanged();
    }
    public void modelChanged() throws FileNotFoundException {
        fontSize = searchModel.getFontSize();
        movieNameLabel.setText(searchModel.currentMovie.getName());
        movieNameLabel.setFont(new Font(fontSize));
        ratingLabel.setText(String.valueOf(searchModel.getRating()));
        ratingLabel.setFont(new Font(fontSize));

        //Creating the ratings section
        ratingHBox.getChildren().clear();
        //This button determines which view is used
        Button changeRating = new Button();
        changeRating.setOnAction(e ->{
            try {
                this.rateMovie(e);
            } catch (FileNotFoundException ex) {
                throw new RuntimeException(ex);
            }
        });

        //If ratings is not selected
        if (!ratingSelect) {
            changeRating.setText("Rate!");
            ratingHBox.getChildren().addAll(rating, ratingLabel, ratingsEnding, changeRating);
        }
        //if ratings is selected
        if (ratingSelect){
            changeRating.setText("Done!");
            ratingHBox.getChildren().addAll(rating,decreaseButton,ratingLabel,ratingsEnding,increaseButton,changeRating);
        }

        genreLabel.setText(searchModel.currentMovie.getGenre());
        genreLabel.setFont(new Font(fontSize));

        //Notes view section
        notesHBox.getChildren().clear();
        notesLabel.setText(searchModel.getNotes());
        notesLabel.setFont(new Font(fontSize));
        notesText.setPromptText("Enter Note");
        notesText.setPrefWidth(300);
        notesText.setAlignment(Pos.TOP_LEFT);
        //When hit, this button will enter the edit view of notes
        Button notesButton = new Button();
        notesButton.setOnAction(e->{
            try {
                this.notesMovie(e);
            } catch (FileNotFoundException ex) {
                throw new RuntimeException(ex);
            }
        });
        //If notes is not selected
        if (!notesSelect){
            notesButton.setText("Write");
            notesHBox.getChildren().addAll(notes,notesLabel,notesButton);
        }
        //if notes is selected
        if (notesSelect){
            notesText.setText(searchModel.getNotes());
            notesHBox.getChildren().addAll(notes,notesText,changeNotes);
        }

        watchDateLabel.setText(searchModel.currentMovie.getWatchDate());
        watchDateLabel.setFont(new Font(fontSize));

        name.setFont(new Font(fontSize));
        rating.setFont(new Font(fontSize));
        ratingsEnding.setFont(new Font(fontSize));
        genre.setFont(new Font(fontSize));
        notes.setFont(new Font(fontSize));
        watch.setFont(new Font(fontSize));
        recommend.setFont(new Font(fontSize));


        ArrayList<String> arrayListInsert = searchModel.getGenre().getTop5Movies("GUI/CSVFiles/movierecommendations.cvs");
        ObservableList<String> observableList = FXCollections.observableArrayList(arrayListInsert);
        ListView<String> listView = new ListView<>(observableList);
        recommendVBox.getChildren().clear();
        recommendVBox.getChildren().add(listView);

        //A WATCHED button will always be added
        //If a Movie List is selected, then add an ADD button
        watchedHBox.getChildren().clear();
        addHBox.getChildren().clear();
        watchedHBox.getChildren().add(watchedButton);
        if (searchModel.movieListIsSelected()){
            addHBox.getChildren().add(addToListButton);
        }
    }
}
