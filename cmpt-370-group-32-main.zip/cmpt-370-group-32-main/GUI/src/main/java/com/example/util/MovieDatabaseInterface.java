package com.example.util;

import java.io.IOException;

/**
 * The interface Movie database interface.
 */
public interface MovieDatabaseInterface {

    /**
     * Add a Movie to the database
     *
     * @param movie the movie
     */
    public void add(Movie movie) throws IOException;

    /**
     * Get the movie from the database
     *
     * @param movieName the movie name
     * @return the movie
     */
    public Movie get(String movieName);

    /**
     * Remove a movie from the database
     *
     * @param movie the movie
     */
    public void remove(String movie);

    /**
     * Clear all values from the database
     */
    public void clear();

    /**
     * Delete the database
     */
    public void delete();

    /**
     * Contains the movies
     *
     * @param movie the movie
     * @return true if contains false otherwise
     */
    public boolean contains(String movie);

}
