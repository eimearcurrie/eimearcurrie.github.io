package com.example.model;

import com.example.view.*;
import com.example.util.*;

/**
 * The Model for Movie History, keeps track of watched movies and alerts the view when changes were made
 */
public class WatchedListModel {
    private WatchedListView view;
    MovieList watched;
    Boolean selected;
    public WatchedListModel(){
        watched = new MovieList("Watched");
        selected = false;
    }

    /**
     * Assigns the Watched List View
     * @param newView the Watched List View used
     */
    public void setView(WatchedListView newView){
        this.view = newView;
    }

    /**
     * Gets the Watched Movie List/ the Movie History
     * @return MovieList which represents the Movie History
     */
    public MovieList getWatched(){return this.watched;}

    /**
     * Gets if the Watched List is selected
     * @return Boolean value which represents the Selection status of the Watched List
     */
    public Boolean getSelected(){
        return this.selected;
    }

    /**
     * Sets the Watched List as selected
     */
    public void setSelected(){
        this.selected = true;
        this.getWatched().selectedList();
    }

    /**
     * Unselects the Watched List
     */
    public void unselect(){
        this.selected = false;
        this.getWatched().unselectList();
    }

    public void notifySubscribers(){
        view.modelChanged();
    }
}
