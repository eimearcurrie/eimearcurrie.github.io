package com.example.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

import java.util.ArrayList;

import com.example.model.*;
import com.example.util.*;

/**
 * The View for the Movie History, displays the movies that the user has watched
 */
public class WatchedListView extends StackPane {
    VBox watchedVBox;
    WatchedListModel model;
    ObservableList<Movie> movieObs;
    ListView<Movie> movieListListView;
    public WatchedListView(){
        this.setMaxSize(2000,1500);
        this.setPrefSize(600,600);

        VBox vBox1 = new VBox();
        Label watchedLabel = new Label("Movie History");
        watchedLabel.setFont(new Font(20));

        ArrayList<Movie> movieArrayList = new ArrayList<>();
        movieObs = FXCollections.observableArrayList(movieArrayList);
        movieListListView = new ListView<>(movieObs);

        //watchedVBox will display all the Movies that the User watched
        watchedVBox = new VBox();
        watchedVBox.setMaxSize(2000,1500);
        watchedVBox.setPrefSize(600,600);
        watchedVBox.setSpacing(3);
        watchedVBox.setPadding(new Insets(2,2,2,2));
        watchedVBox.setStyle("-fx-border-color: black;\n"+"-fx-border-insets: 2;\n"+
                "fx-border-width: 3;\n");


        vBox1.getChildren().addAll(watchedLabel,watchedVBox);
        vBox1.setMaxSize(2000,1500);
        vBox1.setPrefSize(600,600);
        vBox1.setPadding(new Insets(2,2,2,2));
        vBox1.setSpacing(3);

        this.getChildren().add(vBox1);
    }

    /**
     * Assigns the Watched List Model
     * @param newModel the Watched List Model used
     */
    public void setModel(WatchedListModel newModel){
        this.model = newModel;
    }
    public void modelChanged(){
        watchedVBox.getChildren().clear();
        //If the MovieList doesn't contain any movies
        if (model.getWatched().getMovieList().isEmpty()){
            Label emptyListLabel = new Label("The Current List Is Empty");
            watchedVBox.getChildren().add(emptyListLabel);
        }
        //Else display all the movies
        else {
            movieObs = FXCollections.observableArrayList(model.getWatched().getMovieList());
            movieListListView.setItems(movieObs);
            movieListListView.setPrefSize(600,600);
            watchedVBox.getChildren().add(movieListListView);

        }
    }
}
