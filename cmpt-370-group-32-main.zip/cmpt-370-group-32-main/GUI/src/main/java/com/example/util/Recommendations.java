package com.example.util;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;

public class Recommendations {

    /**
     * The name of the Genre
     */
    String genName;

    /**
     * The name of the file containing movie recommendations
     */
    String filename;


    /**
     * the number of top movies per each genre in the file
     */
    int topx;


    /**
     * Creates a new Recommendation
     *
     * @param genreName a String of the name of the genre
     * @param filename  a String of the name of the file contianing the recommendation database
     */

    public Recommendations(String genreName, String filename, int x) {
        this.genName = genreName;
        this.filename = filename;
        this.topx = x;
    }

    /**
     * Creates a list of 5 movie recommendations based on genre
     *
     * @return an ArrayList of Strings contianing 5 movie recommendations from the movie recommendation file
     */

    public ArrayList<String> getRecs() throws FileNotFoundException {
        //create a new ArrayList to store the recommendations
        ArrayList<String> recs = new ArrayList<String>();
        String genre;
        //read the file
        File recdatabase = new File(this.filename);
        //create scanner
        Scanner myScanner = new Scanner(recdatabase);
        myScanner.useDelimiter(",");
//        //Read each line
        while (myScanner.hasNext()) {
            //genre is first part of each line
            genre = myScanner.next();
//            System.out.println(genre);

            // if genre we are on is equal to genre we are looking for
            if (genre.compareTo(this.genName) == 0) {

                //add topx amount to the arraylist
                for(int i = 0; i < this.topx; i ++){
                    recs.add(myScanner.next());
                }
                //else if genre is not equal to genre we are looking for, go to next line
            }
            else{
                myScanner.nextLine();
            }
        }
        //return the ArrayList
        return recs;
    }

}
