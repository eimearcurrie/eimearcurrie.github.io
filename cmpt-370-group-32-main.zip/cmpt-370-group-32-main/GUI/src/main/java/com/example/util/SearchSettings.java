package com.example.util;

import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

import java.io.FileNotFoundException;

import com.example.controller.*;
import com.example.model.*;

/**
 * The View for the Title, Search Bar and the Settings
 */

public class SearchSettings extends StackPane {
    public AutocompletionlTextField searchBar;
    Button searchButton;
    Button settingsButton;
    Boolean selected;
    Boolean fontStatus;
    SearchModel sModel;
    AppController appController;

    public SearchSettings(){
        this.setPrefSize(1400,100);
        this.setMaxSize(2000,1000);
        Label title = new Label("Movie Diary");
        title.setFont(new Font(40));

        this.fontStatus = false;

        selected = false;
        searchBar = new AutocompletionlTextField();
        searchBar.setPromptText("Enter Movie Name");
        searchBar.setAlignment(Pos.CENTER_LEFT);
        searchBar.setPrefWidth(500);
        searchButton = new Button("Search");

        //The search bar
        HBox searchHBox = new HBox();
        searchHBox.setPrefWidth(1400);
        searchHBox.setMaxWidth(2000);
        searchHBox.setSpacing(5);
        searchHBox.getChildren().addAll(searchBar,searchButton);
        searchHBox.setAlignment(Pos.CENTER);

        //The button for the settings
        settingsButton = new Button("Settings");
        HBox settingsHBox = new HBox();
        settingsHBox.setPrefWidth(1400);
        settingsHBox.setMaxWidth(2000);
        settingsHBox.setAlignment(Pos.CENTER_RIGHT);
        settingsHBox.getChildren().add(settingsButton);

        VBox align = new VBox();
        align.setPrefSize(1400,100);
        align.setMaxSize(2000,1000);
        align.getChildren().addAll(settingsHBox,title,searchHBox);
        align.setAlignment(Pos.TOP_CENTER);
        this.getChildren().add(align);
    }

    /**
     * Gets the Text in the Search Bar
     * @return String value of the TextField
     */
    public String getText(){
        return this.searchBar.getText();
    }

    /**
     * Boolean representation if the Settings button is selected, used to determine if Settings is displayed
     * @return Boolean value that represents if the Settings is selected
     */
    public Boolean getSelected(){
        return this.selected;
    }

    /**
     * Sets the Settings as selected
     */
    public void select(){
        this.selected = true;
    }

    /**
     * Unselects the Settings
     */
    public void unselect(){
        this.selected = false;
    }

    public Boolean fontSelected(){
        return this.fontStatus;
    }
    public void fontSelect(ActionEvent event) throws FileNotFoundException {
        if (sModel.getCurrentMovie() != null) {
            this.fontStatus = !this.fontStatus;
            sModel.notifySubscribers();
        }
    }
    /**
     * Assigns the AppController
     * @param controller the AppController used
     */
    public void setController(AppController controller){
        appController = controller;
        searchButton.setOnAction(e ->{
            try {
                appController.handleClickSearch(e);
            }catch (FileNotFoundException ex){
                ex.printStackTrace();
            }
        });
        settingsButton.setOnAction(appController::handleClickSettings);
    }

    public void setsModel(SearchModel sM){
        this.sModel = sM;
        searchBar.getEntries().addAll(this.sModel.getMovieNames());
    }
    //This is more just for show
    //Just paying homage to the unimplemented epics
    public StackPane settingsView(){
        StackPane sView = new StackPane();
        sView.setPrefSize(600,600);
        sView.setMaxSize(2000,1500);

        VBox align = new VBox();
        align.setPrefSize(600,600);
        align.setPadding(new Insets(2,2,2,2));
        align.setSpacing(3);

        Label title = new Label("Settings");
        title.setFont(new Font(20));

        VBox settingsBox = new VBox();
        settingsBox.setPrefSize(600,600);
        settingsBox.setMaxSize(2000,1500);
        settingsBox.setStyle("-fx-border-color: black;\n"+"-fx-border-insets: 2;\n"+
                "fx-border-width: 3;\n");

        HBox userBox = new HBox();
        Button userButton = new Button("Select");
        Label userLabel = new Label("User Settings: ");
        userLabel.setFont(new Font(20));
        userBox.getChildren().addAll(userLabel,userButton);
        userBox.setSpacing(20);

        HBox colorBox = new HBox();
        Button colorButton = new Button("Select");
        Label colorLabel = new Label("Color Settings: ");
        colorLabel.setFont(new Font(20));
        colorBox.getChildren().addAll(colorLabel,colorButton);
        colorBox.setSpacing(10);

        HBox textBox = new HBox();
        Button textButton = new Button("Select");
        Label textLabel = new Label("Text Settings: ");
        textLabel.setFont(new Font(20));
        textBox.getChildren().addAll(textLabel,textButton);
        textBox.setSpacing(20);

        HBox fontBox = new HBox();
        Button fontButton = new Button();
        fontButton.setOnAction(e->{
            try {
                this.fontSelect(e);
            } catch (FileNotFoundException ex) {
                throw new RuntimeException(ex);
            }
        });

        Button increaseButton = new Button("->");
        increaseButton.setOnAction(e->{
            try {
                this.appController.handleFontincrease(e);
            }catch (FileNotFoundException ex){
                throw new RuntimeException(ex);
            }
        });

        Button decreaseButton = new Button("<-");
        decreaseButton.setOnAction(e->{
            try {
                this.appController.handleFontdecrease(e);
            }catch (FileNotFoundException ex){
                throw new RuntimeException(ex);
            }
        });
        Label fontLabel = new Label("Font Settings: ");
        Label sizeLabel = new Label(String.valueOf(sModel.getFontSize()));
        fontLabel.setFont(new Font(20));
        fontBox.setSpacing(20);

        //If the font is selected, then show the font edit display
        if (fontStatus) {
            fontButton.setText("Done");
            fontBox.getChildren().addAll(fontLabel, decreaseButton, sizeLabel, increaseButton, fontButton);
        }
        //If font is not selected then just show the select button
        if (!fontStatus){
            fontButton.setText("Select");
            fontBox.getChildren().addAll(fontLabel,fontButton);
        }

        Button logOut = new Button("Logout");
        logOut.setPrefSize(100,50);
        logOut.setAlignment(Pos.CENTER);

        settingsBox.getChildren().addAll(userBox,colorBox,textBox,fontBox,logOut);
        settingsBox.setSpacing(20);
        settingsBox.setPadding(new Insets(2,2,2,2));

        align.getChildren().addAll(title,settingsBox);
        sView.getChildren().add(align);
        return sView;
    }
}