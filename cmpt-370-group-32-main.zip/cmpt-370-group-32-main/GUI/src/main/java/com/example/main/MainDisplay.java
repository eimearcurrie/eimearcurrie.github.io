package com.example.main;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

import com.example.view.*;
import com.example.model.*;
import com.example.util.*;

/**
 * This will select which view will be displayed
 */
public class MainDisplay extends StackPane {
    PersonalListView pView;
    WatchedListView wView;
    PersonalListModel pModel;
    WatchedListModel wModel;
    SearchSettings searchSettings;
    public MainDisplay(){
        this.setPrefSize(600,600);
        this.setMaxSize(2000,1500);

        //This will at first initialize a view for when none of the views are selected
        VBox emptyVBox = new VBox();
        VBox displayVBox = new VBox();
        displayVBox.setPrefSize(600,600);
        displayVBox.setStyle("-fx-border-color: black;\n"+"-fx-border-insets: 2;\n"+
                "fx-border-width: 3;\n");

        emptyVBox.setPrefSize(600,600);
        emptyVBox.setSpacing(3);
        emptyVBox.setPadding(new Insets(2,2,2,2));
        Label empty = new Label("Main Display");
        empty.setFont(new Font(20));

        emptyVBox.getChildren().addAll(empty,displayVBox);
        this.getChildren().add(emptyVBox);
    }

    /**
     * When the model changes, change the view
     */
    public void modelChanged(){
        showDisplay();
    }

    /**
     * Shows/Updates the display, depends on which model/view is selected by the user
     */
    public void showDisplay(){
        this.getChildren().clear();
        //If a Personal List is selected
        if (this.pModel.getCurr() != null && !this.wModel.getSelected() && !this.searchSettings.getSelected()){
            pView.modelChanged();
            this.getChildren().add(pView);
        }
        //If the Watched List is selected
        else if (this.wModel.getSelected() && this.pModel.getCurr() == null && !this.searchSettings.getSelected()){
            wView.modelChanged();
            this.getChildren().add(wView);
        }
        //If the settings is selected
        else if (!this.wModel.getSelected() && this.pModel.getCurr() == null && this.searchSettings.getSelected()){
            this.getChildren().add(searchSettings.settingsView());
        }
        //Else shows the empty view that was on start up
        //Mainly used for testing if the correct view is selected
        else{
            VBox emptyVBox = new VBox();
            VBox displayVBox = new VBox();
            displayVBox.setPrefSize(600,600);
            displayVBox.setStyle("-fx-border-color: black;\n"+"-fx-border-insets: 2;\n"+
                    "fx-border-width: 3;\n");

            emptyVBox.setPrefSize(600,600);
            emptyVBox.setSpacing(3);
            emptyVBox.setPadding(new Insets(2,2,2,2));
            Label empty = new Label("Main Display");
            empty.setFont(new Font(20));

            emptyVBox.getChildren().addAll(empty,displayVBox);
            this.getChildren().add(emptyVBox);
        }
    }

    /**
     * Assigns the Personal list view
     * @param newView the Personal List used
     */
    public void setPView(PersonalListView newView){
        pView = newView;
    }

    /**
     * Assigns the Watched List view
     * @param newView the Watched List used
     */
    public void setWView(WatchedListView newView){
        wView = newView;
    }

    /**
     * Assigns the Personal List Model
     * @param newModel the Personal List Model selected
     */
    public void setPModel(PersonalListModel newModel){
        pModel = newModel;
    }

    /**
     * Assigns the Watched List Model
     * @param newModel the Watched List Model used
     */
    public void setWModel(WatchedListModel newModel){
        wModel = newModel;
    }

    /**
     * Assigns the Search Settings
     * @param newModel the Search Settings used
     */
    public void setSearchSettings(SearchSettings newModel){
        this.searchSettings = newModel;
    }
}
