package com.example.main;

import javafx.application.HostServices;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.io.IOException;

import com.example.view.*;
import com.example.model.*;
import com.example.util.*;
import com.example.controller.*;

/**
    The MainUI will be in charge of merging all the MVC's together
 */
public class MainUI extends StackPane {
    HostServices hostServices;

    public MainUI(HostServices hostServices) throws IOException {
        this.setMaxSize(2000,1500);
        this.setPrefSize(1420,720);

        PersonalListView personalListView = new PersonalListView();
        WatchedListView watchedListView = new WatchedListView();
        ListSelectionView listSelectionView = new ListSelectionView();
        SearchView searchView = new SearchView();
        MainDisplay mainDisplay = new MainDisplay();

        AppController controller = new AppController();

        controller.setHostServices(hostServices);
        System.out.println(hostServices);

        PersonalListModel personalListModel = new PersonalListModel();
        SearchModel searchModel = new SearchModel();
        WatchedListModel watchedListModel = new WatchedListModel();

        SearchSettings searchSettings = new SearchSettings();

        searchView.setModel(searchModel);
        searchView.setController(controller);
        searchModel.setView(searchView);
        searchModel.setPersonalListModel(personalListModel);
        searchModel.setWatchedListModel(watchedListModel);
        searchModel.setDisplay(mainDisplay);

        personalListView.setModel(personalListModel);
        personalListModel.setView(personalListView);
        personalListModel.setListSelectionView(listSelectionView);
        personalListModel.setDisplay(mainDisplay);

        watchedListView.setModel(watchedListModel);
        watchedListModel.setView(watchedListView);


        controller.setPModel(personalListModel);
        controller.setWModel(watchedListModel);
        controller.setSModel(searchModel);
        controller.setSearchSettings(searchSettings);


        listSelectionView.setPModel(personalListModel);
        listSelectionView.setWModel(watchedListModel);
        listSelectionView.setController(controller);

        mainDisplay.setPModel(personalListModel);
        mainDisplay.setWModel(watchedListModel);
        mainDisplay.setPView(personalListView);
        mainDisplay.setWView(watchedListView);
        mainDisplay.setSearchSettings(searchSettings);

        searchSettings.setController(controller);
        searchSettings.setsModel(searchModel);

        HBox hBox1 = new HBox();
        VBox vBox1 = new VBox();

        hBox1.getChildren().addAll(listSelectionView,mainDisplay,searchView);
        hBox1.setPadding(new Insets(2,2,2,2));
        hBox1.setSpacing(3);

        vBox1.getChildren().addAll(searchSettings,hBox1);
        vBox1.setAlignment(Pos.TOP_CENTER);
        vBox1.setPadding(new Insets(2,2,2,2));
        vBox1.setSpacing(3);

        this.setStyle("-fx-border-color: black;\n");
        this.getChildren().addAll(vBox1);
    }
}
