package com.example.util;

import java.io.*;
import java.util.HashMap;
import java.util.NoSuchElementException;

/**
 * The type Movie database.
 */
public class MovieDatabase implements MovieDatabaseInterface {

    /**
     * The Database.
     */
    public HashMap<String, Movie> database;

    /**
     * The File.
     */
    File file;

    /**
     * Instantiates a new Movie database.
     *
     * @param file the file
     * @throws IOException the io exception
     */
    public MovieDatabase(File file) throws IOException {
        database = new HashMap<String,Movie>();
        this.file = file;
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));

        String line = "";
        while ((line = bufferedReader.readLine()) != null) {
            String[] temp = line.split(",");
            Movie movie = new Movie(temp[0], Integer.parseInt(temp[1]), temp[2], temp[3], temp[4]);
            database.put(movie.getName(),movie);
        }
        bufferedReader.close();

    }

    /**
     * Gets database.
     *
     * @return the database
     */
    public HashMap<String, Movie> getDatabase() {
        if (database == null){
            throw new NullPointerException();
        }
        else return database;
    }

    @Override
    public void add(Movie movie) throws IOException {
        database.put(movie.getName(), movie);
        this.updateFile();
    }

    private void updateFile() throws IOException {
        try {
            try (FileWriter fw = new FileWriter(file) {
            }) {
                for (Movie m: database.values()
                ) {
                    fw.write(m.toString() + '\n');
                }
            }

        } catch (Exception e) {
            System.out.println("Error in writing to file");
            System.exit(1);
        }
    }

    @Override
    public Movie get(String movieName) {
        return database.getOrDefault(movieName, null);
    }


    public void remove(String movieName) throws NoSuchElementException {
        if (!database.containsKey(movieName)) {
            throw new NoSuchElementException();
        }
        database.remove(movieName);
        try {
            this.updateFile();
        }catch (Exception e){
            System.out.println("Error in writing to file");
            System.exit(1);
        }
    }

    @Override
    public void clear() {
        database.clear();
        try {
            this.updateFile();
        }catch (Exception e){
            System.out.println("Error in writing to file");
            System.exit(1);
        }
    }

    @Override
    public void delete() {
        database = null;
        try {
            this.updateFile();
        }catch (Exception e){
            System.out.println("Error in writing to file");
            System.exit(1);
        }
    }

    @Override
    public boolean contains(String movieName) {
        return database.containsKey(movieName);
    }


}
