package com.example.util;

/**
 * The type database_MovieClass.Movie.
 */
public class Movie {

    /**
     * The Name.
     */
    private String name;

    /**
     * The Rating.
     */
    private int rating;

    /**
     * The Notes.
     */
    private String notes;

    /**
     * the genre
     */
    private String genre;

    /**
     * is the movie a favorite
     */
    private Boolean isFavorite = false;

    /**
     * Stores the string in the correct format
     */
    private String whereToWatch = "https://www.justwatch.com/ca/movie/";

    public String linkString = "";



    private String watchDate;

    /**
     * Instantiates a new database_MovieClass.Movie.
     *
     * @param name      the name
     * @param rating    the rating
     * @param notes     the notes
     * @param genre     the genre
     * @param watchDate the watch date
     */
    public Movie(String name, int rating, String notes, String genre, String watchDate){
        //init Components
        this.name = name;
        this.rating = rating;
        this.notes = notes;
        this.genre = genre;
        this.watchDate = watchDate;
        this.linkString=

        //generate where to watch string
        whereToWatch = whereToWatch.concat(this.name.replace("'", "").strip().replace(" ", "-").toLowerCase());
    }

    /**
     * Gets notes.
     *
     * @return the notes
     */
    public String getNotes() {
        return notes;
    }

    /**
     * Sets notes.
     *
     * @param notes the notes
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }

    /**
     * Gets genre.
     *
     * @return the genre
     */
    public String getGenre() {
        return genre;
    }

    /**
     * Sets genre.
     *
     * @param genre the genre
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * Gets favorite.
     *
     * @return True if the movie is a favorite, False otherwise
     */
    public Boolean getFavorite() {return isFavorite;}

    /**
     * Sets favorite.
     *
     * @param favorite True if favorite, false otherwise
     */
    public void setFavorite(Boolean favorite) {isFavorite = favorite;}

    /**
     * Gets whereToWatch string .
     *
     * @return the where to watch
     */
    public String getWhereToWatch() {return whereToWatch;}

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {return name;}

    /**
     * Sets the name.
     *
     * @param name the name
     */
    public void setName(String name) {
        this.name = name;
        while (this.name.contains(" ")) {
            whereToWatch = whereToWatch.concat(this.name.replaceFirst(" ", "-"));
        }
    }

    /**
     * sets new value to rating
     *
     * @param newRating the new rating
     */
    public void setRating(int newRating){this.rating = newRating;}

    /**
     * gets rating
     *
     * @return rating int
     */
    public int getRating(){return this.rating;}


    /**
     * Gets watch date.
     *
     * @return the watch date
     */
    public String getWatchDate() {return watchDate;}

    /**
     * Sets watch date.
     *
     * @param watchDate the watch date
     */
    public void setWatchDate(String watchDate) {this.watchDate = watchDate;}

    /**
     * @return the name, rating, and genre as a string */
    @Override
    public String toString() {
        return name + " " + rating  + "/10 " + genre+"   Notes:   "+notes;
    }
}
