package com.example.controller;

import javafx.application.HostServices;
import javafx.event.ActionEvent;

import java.io.FileNotFoundException;

import com.example.model.*;
import com.example.util.*;

/**
 * The Controller for the entire app, connects to all the required models
 */
public class AppController {
    PersonalListModel pModel;
    WatchedListModel wModel;
    SearchModel sModel;
    SearchSettings searchSettings;
    HostServices hostServices;
    public AppController(){

    }

    /**
     * Assigns the PersonalListModel
     * @param newModel the PersonalListModel used
     */
    public void setPModel(PersonalListModel newModel){pModel = newModel;}

    /**
     * Assigns the WatchedListModel
     * @param newModel the WatchedListModel used
     */
    public void setWModel(WatchedListModel newModel){wModel = newModel;}

    /**
     * Assigns the SearchSettings
     * @param newSearch the SearchSettings used
     */
    public void setSearchSettings(SearchSettings newSearch){
        this.searchSettings = newSearch;
    }

    /**
     *  This function will select the Watched View to be displayed in the Main Display,
     *  unselects the other views
     */
    public void handleClickWatched(ActionEvent event) throws FileNotFoundException {
        wModel.setSelected();
        searchSettings.unselect();
        pModel.unselectCurr();
        //If a movie is searched, changes the model to display the necessary buttons
        //Mainly used to avoid errors
        if (sModel.getCurrentMovie() != null) {
            sModel.view.modelChanged();
        }
    }
    /**
     *  This function will select the Selected Personal List to be displayed in the Main Display,
     *  unselects the other views
     */
    public void handleClickCurrent(ActionEvent event) throws FileNotFoundException {
        pModel.unselectCurr();
        searchSettings.unselect();
        wModel.unselect();
        pModel.setCurr();
        //If a movie is searched, changes the model to display the necessary buttons
        //Mainly used to avoid errors
        if (sModel.getCurrentMovie() != null) {
            sModel.view.modelChanged();
        }
    }

    /**
     * This function will call the deletion of the Selected Personal List
     */
    public void handleClickDelete(ActionEvent event){
        pModel.deleteCurrentList();
    }

    /**
     * This function will call the creation of a new Personal List
     */
    public void handleClickCreate(ActionEvent event){
        pModel.createMovieList();
    }

    /**
     * Assigns the SearchModel
     * @param newModel the SearchModel used
     */
    public void setSModel(SearchModel newModel){this.sModel = newModel;}

    /**
     *  This function will call the search up of a movie
     */
    public void handleClickSearch(ActionEvent event) throws FileNotFoundException {
        sModel.searchBar(searchSettings.getText());
        searchSettings.searchBar.clear();
    }
    /**
     *  This function will select the Settings to be displayed in the Main Display,
     *  unselects the other views
     */
    public void handleClickSettings(ActionEvent event){
        searchSettings.select();
        wModel.unselect();
        pModel.unselectCurr();
    }

    /**
     * This function will call the addition of the Movie to the Selected List
     */
    public void handleAdd(ActionEvent event){
        sModel.addToList();
    }

    /**
     * This function will call the addition of the Movie to the Movie History
     */
    public void handleWatched(ActionEvent event){
        sModel.addToWatched();
    }

    public void linkClicked(ActionEvent event){
        hostServices.showDocument(sModel.getCurrentMovie().getWhereToWatch());
    }

    public void setHostServices(HostServices hostServices){
        this.hostServices=hostServices;
    }

    public void handleFontincrease(ActionEvent event) throws FileNotFoundException {
        if (sModel.getCurrentMovie() != null) {
            sModel.increaseFont();
        }
    }

    public void handleFontdecrease(ActionEvent event) throws FileNotFoundException {
        if (sModel.getCurrentMovie() != null) {
            sModel.decreaseFont();
        }
    }

    /**
     * Increases the Ratings of the searched up Movie
     * @param event ActionEvent
     * @throws FileNotFoundException if file cannot be read
     */
    public void handleIncreaseRating(ActionEvent event) throws FileNotFoundException {
        sModel.increaseRating();
    }

    /**
     * Decreases the Ratings of the searched up movie
     * @param event ActionEvent
     * @throws FileNotFoundException if file cannot be read
     */
    public void handleDecreaseRating(ActionEvent event) throws FileNotFoundException {
        sModel.decreaseRating();
    }

    /**
     * This will call the method in Search Model to change the selected Movie's notes
     * @param event ActionEvent
     */
    public void handleNotesChange(ActionEvent event) throws FileNotFoundException {
        sModel.changeNotes();
    }
}


