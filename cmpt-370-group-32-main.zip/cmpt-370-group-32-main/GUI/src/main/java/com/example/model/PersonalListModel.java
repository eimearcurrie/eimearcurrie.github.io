package com.example.model;

import java.util.ArrayList;

import com.example.view.*;
import com.example.main.*;
import com.example.util.*;

/**
 * The Model for Personal Lists, in charge of keeping track of lists made and functions for modifying the view
 */
public class PersonalListModel {
    ArrayList<MovieList> userLists;
    public MovieList curr;
    private PersonalListView view;
    private ListSelectionView listSelectionView;
    private MainDisplay display;
    int maxList;
    int listCount;
    public PersonalListModel(){
        userLists = new ArrayList<>();
        this.curr = null;
        maxList = 18;
        listCount = 1;
    }

    /**
     * This function will add a new Movie List to the model
     */
    public void createMovieList(){
        if (!listSelectionView.getTextString().isEmpty() && this.getListCount() < getMaxList()) {
            MovieList insert = new MovieList(listSelectionView.getTextString());
            userLists.add(insert);
            listCount += 1;
            listSelectionView.createName.clear();
            notifySubscribers();
        }
    }

    /**
     * Assigns the Personal List View
     * @param newView the Personal List View used
     */
    public void setView(PersonalListView newView){
        view = newView;
    }

    /**
     * Assigns the List Selection View
     * @param newView the List Selection View used
     */
    public void setListSelectionView(ListSelectionView newView){
        listSelectionView = newView;
    }

    /**
     * Assigns the Main Display
     * @param newDisplay the Main Display used
     */
    public void setDisplay(MainDisplay newDisplay){
        this.display = newDisplay;
    }

    /**
     * Gets the ArrayList of MovieLists used in the model
     * @return ArrayList of MovieList
     */
    public ArrayList<MovieList> getUserLists(){return this.userLists;}

    /**
     * Gets the current Movie List selected
     * @return the MovieList selected
     */
    public MovieList getCurr(){return this.curr;}

    /**
     * Sets the Current MovieList selected
     */
    public void setCurr(){
        if (this.curr == null) {
            this.getUserLists().forEach(list -> {
                if (list.getSelectStatus()) {
                    this.curr = list;
                }
            });
        }
        notifySubscribers();
    }

    /**
     * Unselects the Current Movie List selected
     */
    public void unselectCurr(){
        if (this.curr != null) {
            this.curr.unselectList();
            this.curr = null;
        }
        notifySubscribers();
    }
    public void notifySubscribers(){
        listSelectionView.modelChanged();
        display.modelChanged();
    }

    /**
     * Gets the current number of Movie Lists
     * @return Int value representing the number of Movie Lists in the model
     */
    public int getListCount(){
        return this.listCount;
    }

    /**
     * Gets the Max number of Movie Lists that can be made in the Model
     * @return Int value representing the maximum number of Movie List
     */
    public int getMaxList(){
        return this.maxList;
    }

    /**
     * Deletes the Current List Selected
     */
    public void deleteCurrentList(){
        if (this.getCurr() != null && this.getListCount() != 1) {
            userLists.remove(this.getCurr());
            listCount -= 1;
            this.unselectCurr();
        }
        notifySubscribers();
    }
}
