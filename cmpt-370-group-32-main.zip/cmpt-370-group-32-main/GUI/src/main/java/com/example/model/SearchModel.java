package com.example.model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Set;

import com.example.view.*;
import com.example.util.*;
import com.example.main.*;

/**
 * Model for searching for a Movie and getting its information
 */

public class SearchModel {
    public SearchView view;
    MovieDatabase database;
    public Movie currentMovie;
    PersonalListModel personalListModel;
    WatchedListModel watchedListModel;
    Genre genre;

    int fontSize;

    MainDisplay mDisplay;
    int rating;
    String notes;

    public SearchModel() throws IOException {
        //Add the database to the model
        File file = new File("GUI/CSVFiles/movieData.csv");
        this.database = new MovieDatabase(file);
        fontSize = 20;
    }

    /**
     * Gets the current Movie searched
     * @return Movie that was searched up
     */
    public Movie getCurrentMovie(){return this.currentMovie;}

    /**
     * Gets the genre of the Movie searched
     * @return Genre of the Movie searched up
     */
    public Genre getGenre(){return this.genre;}

    /**
     * Adds the Searched up Movie to the Movie List selected
     */
    public void addToList(){
        personalListModel.getCurr().addMovie(this.getCurrentMovie());
        personalListModel.notifySubscribers();
    }

    /**
     * Adds the searched up Movie to the Watched List
     */
    public void addToWatched(){
        watchedListModel.getWatched().addMovie(this.getCurrentMovie());
        watchedListModel.notifySubscribers();
    }

    /**
     * Searches up the Movie, assigns the Movie as the current Movie
     * @param name String value that represents the Movie name
     * @throws FileNotFoundException if the database does not contain the Movie
     */
    public void searchBar(String name) throws FileNotFoundException {
        this.currentMovie = database.get(name);
        this.rating = currentMovie.getRating();
        this.genre = new Genre(this.currentMovie.getGenre());
        this.notes = currentMovie.getNotes();
        notifySubscribers();
    }

    /**
     * Checks if a Movie List is selected
     * @return Boolean value that represents whether a Movie List is selected
     */
    public boolean movieListIsSelected(){
        return this.personalListModel.getCurr() != null;
    }

    /**
     * Assigns the Search View
     * @param newView the Search View used
     */
    public void setView(SearchView newView){
        this.view = newView;
    }

    public void setDisplay(MainDisplay mainDisplay){
        this.mDisplay = mainDisplay;
    }

    /**
     * Assigns a Personal List Model
     * @param pModel the Personal List Model used
     */
    public void setPersonalListModel(PersonalListModel pModel){
        this.personalListModel = pModel;
    }

    /**
     * Assigns the Watched List Model
     * @param wModel the Watched List Model used
     */
    public void setWatchedListModel(WatchedListModel wModel){
        this.watchedListModel = wModel;
    }
    public void notifySubscribers() throws FileNotFoundException {
        view.modelChanged();
        mDisplay.modelChanged();
    }

    public int getFontSize(){
        return fontSize;
    }

    public void increaseFont() throws FileNotFoundException {
        if(fontSize < 35){
            this.fontSize += 1;
        }
        notifySubscribers();
    }

    public void decreaseFont() throws FileNotFoundException {
        if(fontSize > 5) {
            this.fontSize -= 1;
        }
        notifySubscribers();
    }

    /**
     * Gets the ratings of the movie
     * @return int value representing the Movie's rating
     */
    public int getRating(){
        return this.rating;
    }

    /**
     * Decreases the ratings of a movie
     * @throws FileNotFoundException if file not read
     */
    public void decreaseRating() throws FileNotFoundException {
        if (rating > 0) {
            this.rating -= 1;
            database.get(this.currentMovie.getName()).setRating(this.rating);
        }
        notifySubscribers();
    }

    /**
     * Increases the ratings of a movie
     * @throws FileNotFoundException if file not read
     */
    public void increaseRating() throws FileNotFoundException {
        if (rating < 10) {
            this.rating += 1;
            database.get(this.getCurrentMovie().getName()).setRating(this.rating);
        }
        notifySubscribers();
    }

    /**
     * Gets the notes of the selected movie
     * @return String value representing the notes
     */
    public String getNotes(){
        return this.notes;
    }

    /**
     * Changes the notes of a movie
     * @throws FileNotFoundException if file not read
     */
    public void changeNotes() throws FileNotFoundException {
        this.notes = view.notesText.getText();
        this.view.notesSelect = false;
        database.get(this.currentMovie.getName()).setNotes(this.notes);
        notifySubscribers();
    }

    public Set<String> getMovieNames(){
        return database.database.keySet();
    }
}
