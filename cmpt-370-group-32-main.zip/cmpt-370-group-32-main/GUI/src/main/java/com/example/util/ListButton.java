package com.example.util;

import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;

/**
 * The Button for the MovieList's
 */
public class ListButton extends Button {
    Background selectedBG;
    Background unselectedBG;
    public ListButton(String name){
        this.setPrefWidth(300);

        //If the button is selected, highlight it
        selectedBG = new Background(new BackgroundFill(Color.GRAY,new CornerRadii(3),null));
        //If the button is unselected, leave it as it
        unselectedBG = new Background(new BackgroundFill(Color.WHITE,new CornerRadii(3),null));
        setBackground(unselectedBG);

        this.setStyle("-fx-border-color: black;\n"+
                "fx-border-width: 1;\n");
        this.setText(name);
    }

    /**
     * Sets the button as selected
     */
    public void select(){
        setBackground(selectedBG);
    }

    /**
     * Sets the button as unselected
     */
    public void unselect(){
        setBackground(unselectedBG);
    }
}
