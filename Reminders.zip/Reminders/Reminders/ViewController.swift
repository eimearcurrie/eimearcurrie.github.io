//
//  ViewController.swift
//  Reminders
//
//  Created by Eimear Currie on 2022-11-10.
//
//  Resources used:
//      https://cocoacasts.com/ud-5-how-to-store-a-custom-object-in-user-defaults-in-swift
//      <Video>

import UIKit
import UserNotifications

class ViewController: UIViewController {

    @IBOutlet var table : UITableView!
    
    var models = [MyReminder]()
    let defaults = UserDefaults.standard
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let data = defaults.data(forKey: "Reminders"){
            do{
                let decoder = JSONDecoder()
//                self.models = defaults.array(forKey: "Reminders")as? [MyReminder] ?? [MyReminder]()
                self.models = try decoder.decode([MyReminder].self, from: data)

                
            }catch{
                print("Unable to decode reminder (\(error)")
            }
            
            //        let decoded = defaults.data(forKey: "Reminders")
            //        let decodedModels = NSKeyedUnarchiver.unarchiveObject(with: decoded) as! [MyReminder]
            table.delegate = self;
            table.dataSource = self;
        }
    }
    

    
    @IBAction func didTapAdd(){
    
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "add") as? AddViewController else {
            return
        }
        vc.title = "New Reminder"
        vc.navigationItem.largeTitleDisplayMode = .never
        vc.completion = {title, body, date in
            DispatchQueue.main.async {
                self.navigationController?.popToRootViewController(animated: true)
                let new = MyReminder(title: title, date: date, identifier: "id_\(title)")
                self.models.append(new)
                
                
                do{
                    let encoder = JSONEncoder()

                    let data = try encoder.encode(self.models)
                    
                    self.defaults.set(data, forKey: "Reminders")

                    
                }catch{
                    print("Unable to encode array of reminders (\(error))")
                }

                
                self.table.reloadData()
                
                let content = UNMutableNotificationContent()
                content.title = title
                content.sound = .default
                content.body = body
                
                let targetDate = date
                let trigger = UNCalendarNotificationTrigger(dateMatching: Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: targetDate), repeats: false)
                
                
                let request = UNNotificationRequest(identifier: "some_long_id", content: content, trigger: trigger)
                UNUserNotificationCenter.current().add(request, withCompletionHandler: {error in
                    if error != nil{
                        print("something went wrong")
                    }
                })
            }
                
                
            }
        
        navigationController?.pushViewController(vc, animated: true)
    }
//    @IBAction func didTapTest(){
//        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound] , completionHandler: {success, error in
//            if success{
//                //schedule test
//                self.scheduleTest()
//            }
//            else if error != nil{
//                print ("error occured")
//
//            }
//        })
//
//
//    }
//
//
//
//    func scheduleTest(){
//        let content = UNMutableNotificationContent()
//        content.title = "Hello world"
//        content.sound = .default
//        content.body = "body body body body body body body"
//
//        let targetDate = Date().addingTimeInterval(10)
//        let trigger = UNCalendarNotificationTrigger(dateMatching: Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: targetDate), repeats: false)
//
//
//        let request = UNNotificationRequest(identifier: "some_long_id", content: content, trigger: trigger)
//        UNUserNotificationCenter.current().add(request, withCompletionHandler: {error in
//            if error != nil{
//                print("something went wrong")
//            }
//        })
//    }


}

//extension ViewController : UITableViewDelegate{
//
//
//}

extension ViewController : UITableViewDataSource, UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return models.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell",  for: indexPath)
        cell.textLabel?.text = models[indexPath.row].title
        let date = models[indexPath.row].date
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM, dd, YYYY"
        
        cell.detailTextLabel?.text = formatter.string(from: date)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let selected = models[indexPath.row]
        
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)  {
        if editingStyle == .delete{
            tableView.beginUpdates()
            models.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
            
        }
        
        
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
        
    
    
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
   
 
    
 
    
    
        
    
}




struct MyReminder : Codable{
    let title: String
    let date: Date
    let identifier: String
}

